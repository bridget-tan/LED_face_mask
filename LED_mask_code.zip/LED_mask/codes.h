#define MY_PROTOCOL NEC
#define MY_BITS 32
#define OFF 0x010101;
#define WHITE 0xffffff;
#define RED 0xFF0000;
#define GREEN 0x00FF00;
#define BLUE 0x0000FF;
